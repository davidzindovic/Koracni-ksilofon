#ifndef CD74HC4051E_lib_H
#define CD74HC4051E_lib_H

#include <Arduino.h>

bool mux_checkup(uint8_t NoInputs, uint8_t NoChips, uint8_t InputArray[], uint8_t MasterArray[]);

uint64_t digital_pin_check(uint8_t NumInputs, uint8_t NumChips, uint8_t InputArray[], uint8_t MasterArray[], uint8_t ReadPin);

int *analog_pin_check(uint8_t NumInputs, uint8_t NumChips, uint8_t InputArray[], uint8_t MasterArray[], uint8_t ReadPin);

#endif