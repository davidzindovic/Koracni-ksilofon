#include "CD74HC4051E_lib.h"

//SPI pins are reserved, thus we can use 6 mux chips and one master mux
//effectively enabling 48 inputs per ESP module 
//(maybe less, one or two pins go to the DFplayer)

#define READ_PIN 2
#define NUM_INPUTS 16
#define NUM_CHIPS 2

#define DEBUG 1

//insert your S2, S1, S0 and E pins
uint8_t master_mux_array[]={9,10,13,5};

//insert your IC addressess: S2, S1, S0, S2, S1, S0 ...
//							[	 IC1   ][	 IC2	]...
uint8_t input_mux_array[]={25,26,27,4,16,17};


void setup()
{
  Serial.begin(115200);
	
	if(mux_checkup(NUM_INPUTS,NUM_CHIPS,input_mux_array,master_mux_array))
	{
		while(1){}
	}
	
	pinMode(READ_PIN,INPUT);
	
	for(int master=0;master<sizeof(master_mux_array);master++)
	{
		pinMode(master_mux_array[master],OUTPUT);
	}
	
	for(int input=0;input<sizeof(input_mux_array);input++)
	{
		pinMode(input_mux_array[input],OUTPUT);
	}
	Serial.println(pin_check(NUM_INPUTS, NUM_CHIPS,input_mux_array,master_mux_array,READ_PIN),BIN);
}

void loop()
{
	/*
	static uint64_t pins_copy=0;
	static uint64_t pins=0;
	
	pins=pin_check(NUM_INPUTS, NUM_CHIPS,input_mux_array,master_mux_array,READ_PIN);

	if(pins!=pins_copy)
	{
		uint64_t change=pins^pins_copy;
	}
	
	#if DEBUG
		Serial.println(pins);
	#endif

	pins_copy=pins;

	delay(500);*/
}

