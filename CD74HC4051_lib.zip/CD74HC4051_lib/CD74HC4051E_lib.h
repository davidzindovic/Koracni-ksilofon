#ifndef CD74HC4051E_lib_H
#define CD74HC4051E_lib_H

#include <Arduino.h>

void mux_checkup(uint32_t NoInputs, uint32_t NoChips, uint32_t InputArray);

uint32_t pin_check();

#endif