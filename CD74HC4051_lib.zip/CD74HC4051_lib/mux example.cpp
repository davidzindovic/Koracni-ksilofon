#include "CD74HC4051E_lib.h"

#define READ_PIN 2
#define NUM_INPUTS 5
#define NUM_CHIPS 1

#define DEBUG 1

//insert your S2, S1, S0 and E pins
uint8_t master_mux_array[]={9,10,13,5}

//insert your IC addressess: S2, S1, S0, S2, S1, S0 ...
//							[	 IC1   ][	 IC2	]...
uint8_t input_mux_array[]={25,26,27};


void setup()
{
	if(mux_checkup())
	{
		while(1){}
	}
	
	pinMode(READ_PIN,INPUT);
	
	for(int master=0;master<sizeof(master_mux_array);master++)
	{
		pinMode(master_mux_array[master],INPUT);
	}
	
	for(int input=0;input<sizeof(input_mux_array);input++)
	{
		pinMode(input_mux_array[input],INPUT);
	}
	
}

void loop()
{
	static long double pins_copy=0;
	static long double pins=0;
	
	pins=pin_check(NUM_INPUTS, NUM_CHIPS,master_mux_array,input_mux_array,READ_PIN);

	if(abs(pins-pins-copy)>0)
	{
		long double change=pins^pins_copy;
	}
	
	#if DEBUG
		Serial.println(pins,BIN);
	#endif

	pins_copy=pins;

	delay(500);
}

